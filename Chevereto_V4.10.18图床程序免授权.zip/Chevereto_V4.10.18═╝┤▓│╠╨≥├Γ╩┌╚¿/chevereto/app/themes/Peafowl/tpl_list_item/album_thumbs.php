<div class="list-item-thumbs-container">
	<ul class="list-item-thumbs">
		<li data-flag="%ALBUM_IMAGES_SLICE_1_FLAG%">%1<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_1_THUMB_URL%" alt=""></a>%1</li>
		<li data-flag="%ALBUM_IMAGES_SLICE_2_FLAG%">%2<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_2_THUMB_URL%" alt=""></a>%2</li>
		<li data-flag="%ALBUM_IMAGES_SLICE_3_FLAG%">%3<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_3_THUMB_URL%" alt=""></a>%3</li>
		<li data-flag="%ALBUM_IMAGES_SLICE_4_FLAG%">%4<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_4_THUMB_URL%" alt=""></a>%4</li>
	</ul>
</div>