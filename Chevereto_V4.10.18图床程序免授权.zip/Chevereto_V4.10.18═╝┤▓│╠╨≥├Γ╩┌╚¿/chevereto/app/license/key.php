<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
			<inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.
  
  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  源码发布唯一QQ群：687305290 
  源码发布唯一TG：t.me/freechevereto
  源码发布唯一博客：www.sakurabk.net
  
  --------------------------------------------------------------------- */
  
$license = '';