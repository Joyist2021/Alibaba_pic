<?php
define('G_APP_NAME', 'Chevereto');
define('G_APP_VERSION', '3.10.16');