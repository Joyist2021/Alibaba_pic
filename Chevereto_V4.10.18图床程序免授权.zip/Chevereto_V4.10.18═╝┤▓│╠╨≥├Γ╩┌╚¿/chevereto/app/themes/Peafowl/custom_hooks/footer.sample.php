<?php if(!defined('access') or !access) die('This file cannot be directly accessed.'); ?>
<?php /* Add your custom PHP/HTML code in this file */ ?>