<?php
/*
 Your theme functions should be here. You can also add functions overrites here for some internal functions.
 For example, you can overrite get_share_links() or get_peafowl_item_list() here.

  源码发布唯一QQ群：687305290 
  源码发布唯一TG：t.me/freechevereto
  源码发布唯一博客：www.sakurabk.net
  
 */
?>