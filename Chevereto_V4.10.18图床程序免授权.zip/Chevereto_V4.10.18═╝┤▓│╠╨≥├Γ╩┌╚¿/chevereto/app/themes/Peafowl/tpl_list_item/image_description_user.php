<div class="list-item-desc">
	<div class="list-item-desc-title">
		<a href="%IMAGE_URL_VIEWER%" class="list-item-desc-title-link" data-text="image-title" data-content="image-link">%IMAGE_TITLE%</a><span class="display-block font-size-small"><?php _se('by %u', ['%u' => '<a href="%IMAGE_USER_URL%">%IMAGE_USER_NAME%</a>']); ?></span>
	</div>
	%tpl_list_item/item_like% 
</div>