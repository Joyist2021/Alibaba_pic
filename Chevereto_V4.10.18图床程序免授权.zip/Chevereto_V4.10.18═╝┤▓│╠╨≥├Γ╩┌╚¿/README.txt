Requirements
- At least PHP 5.5.0 and MySQL 5
- Apache with mod_rewrite (nginx and other servers needs their own rewrite structure)
- Writing permission in /content and /images

Clean install
1. Upload the contents of the "chevereto" folder to your webserver
2. Go to http://yourwebsite.com and follow the instructions

One click update from 3.X
1. Go to /dashboard and click on "check for updates". If there is an update available you can update directly from your admin dashboard.

Update from 3.X
1. Backup all your file changes (theme, routes, etc.)
2. Upload all the files and folders from "chevereto"
3. Login to your website (admin user) and then run http://www.mysite.com/install
Restore or merge your file changes (only if needed)
* Every release has a list of the affected files which is useful if you are updating from
  immediate previous version and you don't want to overwrite all the files.
* If you are not updating from immediate previous version you should always do the step (2) of this list.

Update from 3.X (ARVIXE)
The update procedure is exactly the same but unless is explicitly mentioned *do not change*
the root .htaccess file. If somehow you replaced this file make sure to have this line of
code at the very top of that file:

AddHandler application/x-httpd-php55 .php55 .php

Update from 2.1 and newer
1. Save the DB connection info from includes/config.php
2. Save the __CHV_CRYPT_SALT__ that you have in includes/definitions.php
3. Upload all the files except for the images folder
4. Go to your website, the system will ask you for the DB connection info
5. Complete the process with the required information
6. The system MUST ask you for your __CHV_CRYPT_SALT__. If not, don't continue the process and ask for support

Update from 2.0.X and older
1. Update to 2.1 or newer using the instructions in those downloads
2. With the system updated you can now use the instructions for 2.1 and newer